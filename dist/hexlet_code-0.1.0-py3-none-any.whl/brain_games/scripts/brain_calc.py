#!/usr/bin/env python3

from brain_games.games.calc import calc_game


def main():
    calc_game()


if __name__ == '__main__':
    main()