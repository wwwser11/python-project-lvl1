
def wrong_answer(x, y, name):
    """
    :param x: user answer
    :param y: correct answer
    :param name: name of player
    :return: text
    """
    return f"'{x}' is wrong answer ;(.\nCorrect answer was {y}. Let's try again, {name}!"
