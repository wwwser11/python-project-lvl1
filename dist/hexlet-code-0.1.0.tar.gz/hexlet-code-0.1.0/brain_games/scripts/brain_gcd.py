#!/usr/bin/env python3

from brain_games.games.gcd import greatest_common_divisor_game as gcd


def main():
    gcd()


if __name__ == '__main__':
    main()